README for Form-Decor

CONTROLS:
Background color buttons - Allows you to decorate the background with a varied range of colors
Foreground color buttons - Allows you to decorate the text/foreground with a varied range of colors
Text size dropdown - Allows you to change the size of all text on the form (with the exception of the title)
Font type dropdown - Allows you to change the type of font of all the text on the form (with the exception of the title)
Font style textbox - Allows you to change the effect of the text from underline, strikeout, bold, and italic
Title textbox - Allows you to change the text of the title

CREDITS:
Form made by Kektsune using Powershell

DOWNLOAD / RELEASES:
In case you can’t find the download or want older versions:  
Form-Decor v1.0.0 Release: https://github.com/kektsune/Form-Decor/tree/main
